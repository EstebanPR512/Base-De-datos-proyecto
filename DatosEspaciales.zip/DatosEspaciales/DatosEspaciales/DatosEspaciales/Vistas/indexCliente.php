<?php
    require('../Singleton/Conexion.php');
    require_once('../DAO/ClienteDAO.php');
    $db = Conexion::getInstancia();
    $ClienteDAO = new ClienteDAO($db);
    $ClienteDTO = $ClienteDAO->mostrarClientes();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap4.min.css">
    <link href="../issets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #007bff;">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Estudiantes</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="CrearCliente.php">Inicio</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="indexCliente.php">Lista Estudiantes</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="crearCliente.php">Crear Estudiantes</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="distanciaCliente.php">Calcular Distancia</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>


    <div class="container">
        <div class="container-fluid">

            <br>
            <h1>Lista de Estudiantes</h1>
            <br>
            <a href="crearCliente.php" class=".bg-gradient-success btn btn-info btn-lg  text-decoration-none">Crear Ubicacion</a>
            <a href="distanciaCliente.php" class=".bg-gradient-success btn btn-info btn-lg  text-decoration-none">Calcular Distancia</a>
            <hr>
            <table id="tabla" class="table table-striped table-bordered" style="width:100%" >
                    <thead>
                        <tr>
                            <th>Cedula</th>
                            <th>Nombre</th>
                            <th>Apellidos</th>
                            <th>Direccion</th>
                            <th>Latitud</th>
                            <th>Longitud</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($ClienteDTO as $Cliente){ ?>
                            <tr>
                                <td> <?php echo $Cliente['Cedula'];?></td>
                                <td> <?php echo $Cliente['Nombre'];?></td>
                                <td> <?php echo $Cliente['Apellidos'];?></td>
                                <td> <?php echo $Cliente['Direccion'];?></td>
                                <td> <?php echo $Cliente['Ubi_Latitud'];?></td>
                                <td> <?php echo $Cliente['Ubi_Longitud'];?></td>
                                <td>
                                    <a class="btn btn-info" name="editar" href="<?php echo "EditarCliente.php?Cedula=" . $Cliente['Cedula']?>">Editar</a>
                                    <a class="btn btn-info" name="eliminar" href="<?php echo "EliminarCliente.php?Cedula=" . $Cliente['Cedula'];?>">Eliminar</a>
                                </td>
                                
                            </tr>
                    <?php } ?>   
                    </tbody>
            </table>
        </div>
    </div>
</body>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready( function () {
        $('#tabla').DataTable();
    } );
</script>

</html>