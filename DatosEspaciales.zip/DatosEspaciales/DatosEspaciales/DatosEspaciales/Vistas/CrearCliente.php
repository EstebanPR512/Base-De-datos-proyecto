<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cliente</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        #miMapa {
            height: 400px;
            width: 100%;
        }
        #suggestions {
            position: absolute;
            z-index: 1000;
            background: white;
            list-style-type: none;
            padding: 0;
            margin: 0;
            max-height: 200px;
            overflow-y: auto;
            width: 100%;
            border: 1px solid #ccc;
        }
        #suggestions li {
            padding: 10px;
            cursor: pointer;
        }
        #suggestions li:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #007bff;">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Estudiantes</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="CrearCliente.php">Inicio</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="indexCliente.php">Lista Estudiantes</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="crearCliente.php">Crear Estudiantes</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="distanciaCliente.php">Calcular Distancia</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
 
    <div class="container">
        <br>
        <a class="btn btn-danger btn-lg text-decoration-none" href="indexCliente.php">Volver</a>
        <br><br>
        <h1>Formulario de Registro</h1>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <form method="POST" action="../Controladores/ControladorCliente.php">
                    <input type="hidden" name="crear" value="1">
                    <h2 class="h4 mb-3 text-gray-800">Cedula</h2>
                    <input type="text" class="form-control" placeholder="Cedula" aria-label="Cedula" name="cedula" />
                    <br>
                    <h2 class="h4 mb-3 text-gray-800">Nombre</h2>
                    <input type="text" class="form-control" placeholder="Nombre" aria-label="Nombre" name="nombre"/>
                    <br>
                    <h2 class="h4 mb-3 text-gray-800">Apellidos</h2>
                    <input type="text" class="form-control" placeholder="Apellidos" aria-label="Apellidos" name="apellidos"/>
                    <br>
                    <h2 class="h4 mb-3 text-gray-800">Direccion</h2>
                    <div style="position: relative;">
                        <input type="text" class="form-control" placeholder="Direccion" aria-label="Direccion" name="direccion" id="direccion"/>
                        <ul id="suggestions"></ul>
                    </div>
                    <br>
                    <h2 class="h4 mb-3 text-gray-800">Ubicacion - Latitud</h2>
                    <input type="text" class="form-control" placeholder="Latitud" aria-label="Latitud" name="ubi_latitud" id="ubi_latitud"/>
                    <br>
                    <h2 class="h4 mb-3 text-gray-800">Ubicacion - Longitud</h2>
                    <input type="text" class="form-control" placeholder="Longitud" aria-label="Longitud" name="ubi_longitud" id="ubi_longitud"/>
                    <br>
                    <button type="submit" class="btn btn-danger" style="background-color: #007bff;">Guardar Usuario</button>

                </form>
            </div>
            <div class="col-md-6">
                <h2>Mapa</h2>
                <div id="miMapa"></div>
            </div>
        </div>
    </div>
 
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var map = L.map('miMapa').setView([4.631826, -74.080483], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
 
        var marker;
 
        function updateMarker(latlng) {
            if (marker) {
                map.removeLayer(marker);
            }
            marker = L.marker(latlng).addTo(map);
            document.getElementById('ubi_latitud').value = latlng.lat.toFixed(6);
            document.getElementById('ubi_longitud').value = latlng.lng.toFixed(6);
            map.setView(latlng, 16);
        }
 
        map.on('click', function(e) {
            updateMarker(e.latlng);
            reverseGeocode(e.latlng.lat, e.latlng.lng);
        });
 
        var direccionInput = document.getElementById('direccion');
        var suggestionsContainer = document.getElementById('suggestions');
 
        direccionInput.addEventListener('input', function() {
            if (this.value.length > 2) {
                geocode(this.value);
            } else {
                suggestionsContainer.innerHTML = '';
            }
        });
 
        function geocode(query) {
            fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    suggestionsContainer.innerHTML = '';
                    data.forEach(result => {
                        var li = document.createElement('li');
                        li.textContent = result.display_name;
                        li.addEventListener('click', function() {
                            direccionInput.value = result.display_name;
                            updateMarker(L.latLng(result.lat, result.lon));
                            suggestionsContainer.innerHTML = '';
                        });
                        suggestionsContainer.appendChild(li);
                    });
                });
        }
 
        function reverseGeocode(lat, lon) {
            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`)
                .then(response => response.json())
                .then(data => {
                    if (data.display_name) {
                        direccionInput.value = data.display_name;
                    }
                });
        }
    });
    </script>
</body>
</html>